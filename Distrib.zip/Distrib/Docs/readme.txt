﻿COMScales
Компонента для получения веса с весовых терминалов в 1С

Курдюков Алексей Евгеньевич
necroalone@gmail.com
comscales@gmail.com
https://github.com/AlexNecro/COMScales
